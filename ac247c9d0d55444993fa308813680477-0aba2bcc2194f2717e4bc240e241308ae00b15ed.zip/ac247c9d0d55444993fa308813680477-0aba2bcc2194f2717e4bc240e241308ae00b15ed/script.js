// Select the form and the Next button
const form = document.getElementById('libraryForm');
const nextStepButton = document.getElementById('next-step1');

// Function to validate the current step
nextStepButton.addEventListener('click', function (event) {
    // Prevent navigation if fields are invalid
    const requiredFields = document.querySelectorAll('#step1 ~ .step input:required, #step1 ~ .step select:required');
    let allValid = true;

    requiredFields.forEach((field) => {
        if (!field.checkValidity()) {
            allValid = false;
            field.reportValidity(); // Display browser's validation message
        }
    });

    if (!allValid) {
        event.preventDefault(); // Stop navigation if validation fails
    }
});

// Function to handle form submission
form.addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent actual form submission
    console.log('Form Submitted'); // Print "Form Submitted" in the console
    alert('Form Submitted Successfully!'); // Alert success to the user
});
